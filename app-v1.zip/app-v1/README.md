# Aplikasi Pengadaan Barang<br/>
## Free Source Code<br/>

### Aplikasi ini dibuat menggunakan
- Codeigniter 3
- Bootstrap 4
- SB Admin 2 Template
- Datatables
- Chart.js

### Keterangan <br/>
Database : <code>ci_barang</code><br/>
<br/>
